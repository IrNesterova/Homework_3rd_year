create function substraction_transition(state complex, val complex) returns complex
    language plpgsql
as
$$
begin
        return row(state.re - val.re, state.im - val.im)::complex;
    end;
$$;

alter function substraction_transition(complex, complex) owner to postgres;

