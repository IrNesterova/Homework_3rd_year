create function sum_of_matrix(state integer[], state_other integer[]) returns integer[]
    language plpgsql
as
$$
begin
        if array_length(state, 1) is null
            then return state_other;
        end if;
        for i in 1..array_length(state, 1) loop
            for j in 1..array_length(state_other, 2) loop
                state[i][j] = state[i][j] + case when state_other[i][j] is null then 0 else state_other[i][j] end;
                end loop;
            end loop;
        return state;
    end;
$$;

alter function sum_of_matrix(integer[], integer[]) owner to postgres;

