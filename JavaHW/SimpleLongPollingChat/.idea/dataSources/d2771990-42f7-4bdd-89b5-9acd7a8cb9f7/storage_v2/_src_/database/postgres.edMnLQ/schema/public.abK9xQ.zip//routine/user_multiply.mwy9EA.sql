create function user_multiply(state1 complex, state2 complex) returns complex
    language plpgsql
as
$$
begin
   return ROW(state1.re * state2.re - state1.im * state2.im, state1.re * state2.im + state1.im * state2.re)::complex;
   end;
$$;

alter function user_multiply(complex, complex) owner to postgres;

