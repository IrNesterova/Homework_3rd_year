create function user_sum(state complex, val complex) returns complex
    language plpgsql
as
$$
begin
            return row(state.re + val.re, state.im + val.im)::complex;
        end;
$$;

alter function user_sum(complex, complex) owner to postgres;

