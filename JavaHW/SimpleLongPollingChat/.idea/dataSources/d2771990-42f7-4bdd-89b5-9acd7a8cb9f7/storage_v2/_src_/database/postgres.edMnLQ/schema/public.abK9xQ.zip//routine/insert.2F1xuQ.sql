create function insert() returns trigger
    language plpgsql
as
$$
declare
            table_name_insert varchar;
            constraint_name varchar;
            trigger_name varchar;
            table_num integer;
            begin_value integer;
            end_value integer;
            trigger_cnt integer;
        begin
            table_num := trunc(new.id / 100000);
            table_name_insert := 'inherit' || table_num;
            constraint_name := 'check' || table_num;
            trigger_name := 'redirect_insert_to_inherit' || table_num;
            begin_value := table_num * 100000;
            end_value := begin_value + 99999;
            execute 'CREATE TABLE IF NOT EXISTS ' || table_name_insert || ' (CONSTRAINT ' || constraint_name || ' CHECK (id between ' || begin_value ||' and ' || end_value || ')) inherits (table_12_hub)';
            execute 'insert into ' || table_name_insert || ' values($1, $2)' using new.id, new.name;

            return null;
        end;
$$;

alter function insert() owner to postgres;

