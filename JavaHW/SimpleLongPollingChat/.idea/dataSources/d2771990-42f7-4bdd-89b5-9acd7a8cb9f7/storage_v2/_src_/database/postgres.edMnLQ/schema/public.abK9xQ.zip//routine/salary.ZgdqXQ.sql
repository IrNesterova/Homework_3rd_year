create function salary(p2 numeric) returns text
    language sql
as
$$
select name from public.emp where salary = p2;
$$;

alter function salary(numeric) owner to postgres;

