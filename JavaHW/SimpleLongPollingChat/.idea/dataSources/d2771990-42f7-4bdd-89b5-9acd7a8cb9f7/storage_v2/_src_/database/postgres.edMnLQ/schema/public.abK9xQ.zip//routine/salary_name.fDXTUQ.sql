create function salary_name(p1 numeric) returns text
    language plpgsql
as
$$
declare
        name1 text;
    begin
        select name from public.emp where salary = p1 into name1;
        return name1;
    end;
$$;

alter function salary_name(numeric) owner to postgres;

