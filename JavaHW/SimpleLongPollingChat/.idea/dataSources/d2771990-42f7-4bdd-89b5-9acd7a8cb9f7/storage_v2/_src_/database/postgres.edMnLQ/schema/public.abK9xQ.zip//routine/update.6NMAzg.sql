create function update() returns trigger
    language plpgsql
as
$$
begin
    insert into table_12_hub(id, name) values (new.id, new.name);
    delete from table_12_hub where id = old.id;
            
end;
$$;

alter function update() owner to postgres;

