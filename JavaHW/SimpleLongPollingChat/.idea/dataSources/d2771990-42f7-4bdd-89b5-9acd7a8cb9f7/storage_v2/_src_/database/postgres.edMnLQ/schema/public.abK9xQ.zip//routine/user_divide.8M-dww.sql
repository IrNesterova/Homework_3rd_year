create function user_divide(state1 complex, state2 complex) returns complex
    language plpgsql
as
$$
begin
        return row((state1.re*state2.re + state1.im*state2.im)/(state2.re*state2.re + state1.im*state1.im), (state2.re*state1.im - state1.re*state2.im) / (state2.re*state2.re + state2.im*state2.im))::complex;
    end;
$$;

alter function user_divide(complex, complex) owner to postgres;

